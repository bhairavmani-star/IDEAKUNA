import { useEffect, useState, useRef } from 'react';

interface StartupSequenceProps {
  onComplete: () => void;
}

export default function StartupSequence({ onComplete }: StartupSequenceProps) {
  const [showVideo, setShowVideo] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const hasCompletedRef = useRef(false);

  useEffect(() => {
    // Show black screen for 0.3 seconds
    const blackScreenTimer = setTimeout(() => {
      setShowVideo(true);
    }, 300);

    return () => clearTimeout(blackScreenTimer);
  }, []);

  useEffect(() => {
    if (!showVideo || !videoRef.current) {
      return;
    }

    const video = videoRef.current;

    // Handle video end - trigger transition immediately
    const handleVideoEnded = () => {
      if (!hasCompletedRef.current) {
        console.log('Startup sequence: Video ended, transitioning to homepage');
        hasCompletedRef.current = true;
        onComplete();
      }
    };

    // Handle errors gracefully
    const handleError = (e: Event) => {
      console.error('Startup sequence: Video error:', e);
      if (!hasCompletedRef.current) {
        hasCompletedRef.current = true;
        onComplete();
      }
    };

    // Attach event listeners before playing
    video.addEventListener('ended', handleVideoEnded);
    video.addEventListener('error', handleError);

    // Start playback
    const playVideo = async () => {
      try {
        video.currentTime = 0;
        await video.play();
        console.log('Startup sequence: Video playback started (muted)');
      } catch (error) {
        console.error('Startup sequence: Error playing video:', error);
        // Fallback: complete after a delay if play fails
        setTimeout(() => {
          if (!hasCompletedRef.current) {
            hasCompletedRef.current = true;
            onComplete();
          }
        }, 5000);
      }
    };

    // Wait for video to be ready, then play
    if (video.readyState >= HTMLMediaElement.HAVE_ENOUGH_DATA) {
      playVideo();
    } else {
      video.addEventListener('canplaythrough', playVideo, { once: true });
    }

    return () => {
      video.removeEventListener('ended', handleVideoEnded);
      video.removeEventListener('error', handleError);
      if (!video.paused) {
        video.pause();
      }
    };
  }, [showVideo, onComplete]);

  return (
    <div className="fixed inset-0 z-50 bg-black flex items-center justify-center overflow-hidden">
      {showVideo ? (
        <video
          ref={videoRef}
          muted
          playsInline
          className="w-full h-full object-cover"
          preload="auto"
          disablePictureInPicture
          controlsList="nodownload nofullscreen noremoteplayback"
        >
          <source src="/assets/Screenrecorder-2026-01-28-21-34-45-105~2-2.mp4" type="video/mp4" />
        </video>
      ) : (
        <div className="w-full h-full bg-black" />
      )}
    </div>
  );
}
