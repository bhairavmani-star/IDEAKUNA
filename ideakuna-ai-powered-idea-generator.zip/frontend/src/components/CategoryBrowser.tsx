import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Lightbulb, Palette, MessageCircle, Globe } from 'lucide-react';
import { useCategories, useGenerateCategoryIdea } from '../hooks/useQueries';
import IdeaDisplay from './IdeaDisplay';

const categoryIcons: Record<string, React.ReactNode> = {
  Projects: <Lightbulb className="h-6 w-6" />,
  Creativity: <Palette className="h-6 w-6" />,
  Greetings: <MessageCircle className="h-6 w-6" />,
  'Web Creation': <Globe className="h-6 w-6" />,
};

export default function CategoryBrowser() {
  const { data: categories, isLoading } = useCategories();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const generateIdea = useGenerateCategoryIdea();

  const handleGenerateIdea = (categoryName: string) => {
    setSelectedCategory(categoryName);
    generateIdea.mutate(categoryName);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="grid gap-6 md:grid-cols-2">
        {categories?.map((category) => (
          <Card
            key={category.name}
            className="group relative overflow-hidden transition-all hover:shadow-lg hover:border-primary/50"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity" />
            
            <CardHeader className="relative">
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-primary/10 to-accent/10 text-primary group-hover:from-primary/20 group-hover:to-accent/20 transition-colors">
                  {categoryIcons[category.name] || <Lightbulb className="h-6 w-6" />}
                </div>
                <div className="flex-1">
                  <CardTitle className="text-xl">{category.name}</CardTitle>
                  <CardDescription className="mt-1.5">
                    {category.description}
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="relative">
              <Button
                onClick={() => handleGenerateIdea(category.name)}
                disabled={generateIdea.isPending && selectedCategory === category.name}
                className="w-full bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90"
              >
                {generateIdea.isPending && selectedCategory === category.name ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Jogo is thinking...
                  </>
                ) : (
                  <>
                    <Lightbulb className="mr-2 h-4 w-4" />
                    Ask Jogo for Ideas
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {generateIdea.isSuccess && generateIdea.data && generateIdea.data.trim() && (
        <IdeaDisplay
          idea={generateIdea.data}
          category={selectedCategory}
          isLoading={generateIdea.isPending}
        />
      )}
    </div>
  );
}
