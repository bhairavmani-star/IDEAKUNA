import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LayoutGrid, Search, MessageSquare, Image } from 'lucide-react';
import CategoryBrowser from './CategoryBrowser';
import SearchMode from './SearchMode';
import JogoChat from './JogoChat';
import JogoImageGen from './JogoImageGen';

export default function IdeaGenerator() {
  const [activeTab, setActiveTab] = useState<string>('categories');

  return (
    <section className="py-16 md:py-24">
      <div className="container">
        <div className="mx-auto max-w-5xl">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">
              Meet{' '}
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Jogo
              </span>
            </h2>
            <p className="text-muted-foreground">
              Your AI assistant for ideas, conversations, and image generation
            </p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="grid w-full max-w-2xl grid-cols-4">
                <TabsTrigger value="categories" className="gap-2">
                  <LayoutGrid className="h-4 w-4" />
                  <span className="hidden sm:inline">Categories</span>
                </TabsTrigger>
                <TabsTrigger value="search" className="gap-2">
                  <Search className="h-4 w-4" />
                  <span className="hidden sm:inline">Search</span>
                </TabsTrigger>
                <TabsTrigger value="chat" className="gap-2">
                  <MessageSquare className="h-4 w-4" />
                  <span className="hidden sm:inline">Chat</span>
                </TabsTrigger>
                <TabsTrigger value="image" className="gap-2">
                  <Image className="h-4 w-4" />
                  <span className="hidden sm:inline">Images</span>
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="categories" className="mt-0">
              <CategoryBrowser />
            </TabsContent>

            <TabsContent value="search" className="mt-0">
              <SearchMode />
            </TabsContent>

            <TabsContent value="chat" className="mt-0">
              <JogoChat />
            </TabsContent>

            <TabsContent value="image" className="mt-0">
              <JogoImageGen />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </section>
  );
}
