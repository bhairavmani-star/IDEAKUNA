import { Sparkles } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-border/40">
      {/* Background image with overlay */}
      <div className="absolute inset-0">
        <img 
          src="/assets/generated/homepage-background.dim_1200x800.jpg" 
          alt="Background"
          className="w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />
      </div>
      
      <div className="container relative py-16 md:py-24">
        <div className="mx-auto max-w-4xl text-center space-y-8">
          {/* Creator attribution banner with glowing effect */}
          <div className="mb-8">
            <h3 className="text-2xl md:text-3xl font-bold text-glow animate-pulse-glow">
              This website was created by Bhairav Mani.R / Yeshwanth.B
            </h3>
          </div>

          {/* Main heading */}
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-sm">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-foreground">AI-Powered Idea Generation</span>
            </div>
            
            <h2 className="text-4xl md:text-6xl font-bold tracking-tight">
              Discover Ideas That{' '}
              <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                Inspire
              </span>
            </h2>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Unlock your creativity with AI-generated ideas. Browse by category or search for anything—we only give ideas.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
