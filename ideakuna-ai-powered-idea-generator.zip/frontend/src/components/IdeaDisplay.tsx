import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Lightbulb, Sparkles } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface IdeaDisplayProps {
  idea: string;
  category?: string | null;
  searchTerm?: string;
  isLoading?: boolean;
}

export default function IdeaDisplay({ idea, category, searchTerm, isLoading }: IdeaDisplayProps) {
  if (isLoading) {
    return null;
  }

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <Card className="border-primary/20 bg-gradient-to-br from-card to-card/50 shadow-xl">
        <CardHeader>
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent">
                <Lightbulb className="h-5 w-5 text-primary-foreground" />
              </div>
              <CardTitle className="text-xl">Jogo's Idea</CardTitle>
            </div>
            {category && (
              <Badge variant="secondary" className="gap-1">
                <Sparkles className="h-3 w-3" />
                {category}
              </Badge>
            )}
            {searchTerm && (
              <Badge variant="secondary" className="gap-1">
                <Sparkles className="h-3 w-3" />
                {searchTerm}
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="prose prose-sm dark:prose-invert max-w-none">
            <p className="text-base leading-relaxed whitespace-pre-wrap">{idea}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
