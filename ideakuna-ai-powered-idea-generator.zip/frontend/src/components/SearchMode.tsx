import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Loader2, Sparkles } from 'lucide-react';
import { useSearchIdeas } from '../hooks/useQueries';
import IdeaDisplay from './IdeaDisplay';

export default function SearchMode() {
  const [searchTerm, setSearchTerm] = useState('');
  const searchIdeas = useSearchIdeas();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      searchIdeas.mutate(searchTerm);
    }
  };

  return (
    <div className="space-y-8">
      <div className="mx-auto max-w-2xl">
        <div className="rounded-2xl border border-border/50 bg-card p-8 shadow-lg">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-primary/10 to-accent/10">
                <Sparkles className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">Search for Ideas with Jogo</h3>
                <p className="text-sm text-muted-foreground">
                  Type anything and let Jogo generate ideas for you
                </p>
              </div>
            </div>

            <form onSubmit={handleSearch} className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="e.g., birthday party themes, startup ideas, blog topics..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-12 text-base"
                />
              </div>

              <Button
                type="submit"
                disabled={!searchTerm.trim() || searchIdeas.isPending}
                className="w-full h-12 bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 text-base"
              >
                {searchIdeas.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Jogo is generating ideas...
                  </>
                ) : (
                  <>
                    <Search className="mr-2 h-5 w-5" />
                    Ask Jogo
                  </>
                )}
              </Button>
            </form>
          </div>
        </div>
      </div>

      {searchIdeas.isSuccess && searchIdeas.data && searchIdeas.data.trim() && (
        <IdeaDisplay
          idea={searchIdeas.data}
          searchTerm={searchTerm}
          isLoading={searchIdeas.isPending}
        />
      )}
    </div>
  );
}
