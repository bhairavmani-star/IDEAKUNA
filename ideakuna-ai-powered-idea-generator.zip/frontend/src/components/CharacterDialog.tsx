import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ChevronUp } from 'lucide-react';

export default function CharacterDialog() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Character image with pulsing arrow */}
      <div className="fixed bottom-8 right-8 z-40 flex flex-col items-center gap-2">
        <div className="flex flex-col items-center animate-bounce-gentle">
          <ChevronUp className="h-6 w-6 text-primary animate-pulse-glow" />
          <span className="text-sm font-medium text-primary animate-pulse-glow">
            click me
          </span>
        </div>
        <button
          onClick={() => setIsOpen(true)}
          className="relative group cursor-pointer transition-transform hover:scale-110 active:scale-95"
          aria-label="Open character dialog"
        >
          <img
            src="/assets/generated/sukuna-character-transparent.dim_200x200.png"
            alt="Ryomen Sukuna character"
            className="w-32 h-32 md:w-40 md:h-40 object-contain drop-shadow-2xl"
          />
          <div className="absolute inset-0 rounded-full bg-primary/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
        </button>
      </div>

      {/* Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Ryomen Sukuna Says
            </DialogTitle>
            <DialogDescription className="text-base pt-4">
              This website is created by Bhairav Mani.R gambare gambare
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-center py-4">
            <img
              src="/assets/generated/sukuna-character-transparent.dim_200x200.png"
              alt="Ryomen Sukuna character"
              className="w-32 h-32 object-contain"
            />
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
