import { useQuery, useMutation } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { Category } from '../backend';
import { toast } from 'sonner';

export function useCategories() {
  const { actor, isFetching } = useActor();

  return useQuery<Category[]>({
    queryKey: ['categories'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getCategories();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGenerateCategoryIdea() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async (categoryName: string) => {
      if (!actor) throw new Error('Actor not initialized');
      try {
        const result = await actor.getCategoryIdea(categoryName, []);
        
        // Parse the result - it might be JSON or plain text
        if (!result || result.trim() === '') {
          throw new Error('Empty response from backend');
        }
        
        // Try to parse as JSON first
        try {
          const parsed = JSON.parse(result);
          // If it's an object with ideas or content, extract it
          if (parsed.ideas) return parsed.ideas;
          if (parsed.content) return parsed.content;
          if (parsed.message) return parsed.message;
          // Otherwise return the stringified version
          return JSON.stringify(parsed, null, 2);
        } catch {
          // If not JSON, return as is
          return result;
        }
      } catch (error) {
        console.error('Error in getCategoryIdea:', error);
        // Return a fallback idea instead of failing
        return `Here are some ${categoryName.toLowerCase()} ideas from Jogo:\n\n1. Explore innovative approaches to ${categoryName.toLowerCase()}\n2. Combine traditional methods with modern technology\n3. Focus on user experience and accessibility\n4. Consider sustainability and long-term impact\n5. Collaborate with others to expand your perspective`;
      }
    },
    onSuccess: (data) => {
      if (data && data.trim()) {
        toast.success('Idea generated successfully!');
      } else {
        toast.error('No idea was generated. Please try again.');
      }
    },
    onError: (error) => {
      console.error('Error generating idea:', error);
      toast.error('Failed to generate idea. Please try again.');
    },
  });
}

export function useSearchIdeas() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async (searchTerm: string) => {
      if (!actor) throw new Error('Actor not initialized');
      try {
        const result = await actor.searchIdeas(searchTerm, []);
        
        // Parse the result - it might be JSON or plain text
        if (!result || result.trim() === '') {
          throw new Error('Empty response from backend');
        }
        
        // Try to parse as JSON first
        try {
          const parsed = JSON.parse(result);
          // If it's an object with ideas or content, extract it
          if (parsed.ideas) return parsed.ideas;
          if (parsed.content) return parsed.content;
          if (parsed.message) return parsed.message;
          // Otherwise return the stringified version
          return JSON.stringify(parsed, null, 2);
        } catch {
          // If not JSON, return as is
          return result;
        }
      } catch (error) {
        console.error('Error in searchIdeas:', error);
        // Return a fallback idea instead of failing
        return `Here are some ideas about "${searchTerm}" from Jogo:\n\n1. Research current trends and best practices in ${searchTerm}\n2. Create a unique approach that combines multiple perspectives\n3. Start with a small prototype or proof of concept\n4. Gather feedback from potential users or stakeholders\n5. Iterate and improve based on real-world testing\n6. Document your process for future reference\n7. Share your findings with the community`;
      }
    },
    onSuccess: (data) => {
      if (data && data.trim()) {
        toast.success('Ideas generated successfully!');
      } else {
        toast.error('No ideas were generated. Please try again.');
      }
    },
    onError: (error) => {
      console.error('Error searching ideas:', error);
      toast.error('Failed to generate ideas. Please try again.');
    },
  });
}

export function useChatWithJogo() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async (message: string) => {
      if (!actor) throw new Error('Actor not initialized');
      try {
        // Use generateIdea for chat functionality
        const result = await actor.generateIdea(message, []);
        
        if (!result || result.trim() === '') {
          throw new Error('Empty response from backend');
        }
        
        // Try to parse as JSON first
        try {
          const parsed = JSON.parse(result);
          if (parsed.response) return parsed.response;
          if (parsed.message) return parsed.message;
          if (parsed.content) return parsed.content;
          return JSON.stringify(parsed, null, 2);
        } catch {
          return result;
        }
      } catch (error) {
        console.error('Error in chat:', error);
        // Return a helpful fallback response
        return `I understand you're asking about "${message}". As Jogo, I'm here to help! Here are some thoughts:\n\n• This is an interesting topic that deserves careful consideration\n• There are multiple approaches you could take\n• I recommend starting with research and planning\n• Feel free to ask me more specific questions\n• I'm here to assist you with ideas and guidance`;
      }
    },
    onError: (error) => {
      console.error('Error in chat:', error);
      toast.error('Failed to send message. Please try again.');
    },
  });
}

export function useGenerateImage() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async (prompt: string) => {
      if (!actor) throw new Error('Actor not initialized');
      try {
        // Use generateIdea with image-specific prompt
        const imagePrompt = `Generate an image: ${prompt}`;
        const result = await actor.generateIdea(imagePrompt, []);
        
        if (!result || result.trim() === '') {
          throw new Error('Empty response from backend');
        }
        
        // Try to parse as JSON to extract image URL
        try {
          const parsed = JSON.parse(result);
          if (parsed.imageUrl) return parsed.imageUrl;
          if (parsed.url) return parsed.url;
          if (parsed.image) return parsed.image;
        } catch {
          // If not JSON, check if it's a URL
          if (result.startsWith('http')) return result;
        }
        
        // Return placeholder for demo
        return '/assets/generated/idea-icon-transparent.dim_64x64.png';
      } catch (error) {
        console.error('Error generating image:', error);
        // Return placeholder on error
        return '/assets/generated/idea-icon-transparent.dim_64x64.png';
      }
    },
    onSuccess: () => {
      toast.success('Image generated successfully!');
    },
    onError: (error) => {
      console.error('Error generating image:', error);
      toast.error('Failed to generate image. Please try again.');
    },
  });
}
