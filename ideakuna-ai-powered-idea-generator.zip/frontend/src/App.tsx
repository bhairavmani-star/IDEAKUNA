import { useEffect, useState } from 'react';
import { ThemeProvider } from 'next-themes';
import { Toaster } from '@/components/ui/sonner';
import Header from './components/Header';
import Hero from './components/Hero';
import IdeaGenerator from './components/IdeaGenerator';
import Footer from './components/Footer';
import StartupSequence from './components/StartupSequence';
import CharacterDialog from './components/CharacterDialog';
import { useActor } from './hooks/useActor';

function App() {
  const { actor } = useActor();
  const [showStartup, setShowStartup] = useState(true);
  const [startupCompleted, setStartupCompleted] = useState(false);

  // Initialize categories on mount
  useEffect(() => {
    if (actor) {
      actor.initializeCategories().catch(console.error);
    }
  }, [actor]);

  const handleStartupComplete = () => {
    // Prevent multiple calls
    if (!startupCompleted) {
      setStartupCompleted(true);
      setShowStartup(false);
    }
  };

  if (showStartup) {
    return <StartupSequence onComplete={handleStartupComplete} />;
  }

  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
      <div className="min-h-screen flex flex-col bg-background animate-in fade-in">
        <Header />
        <main className="flex-1">
          <Hero />
          <IdeaGenerator />
        </main>
        <Footer />
        <CharacterDialog />
        <Toaster />
      </div>
    </ThemeProvider>
  );
}

export default App;
