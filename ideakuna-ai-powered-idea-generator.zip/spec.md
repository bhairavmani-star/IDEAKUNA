# IDEAKUNA   AI Powered Idea Generator

## Overview
IDEAKUNA is a minimalist web application that generates creative ideas through AI. The platform features "Jogo", an AI assistant that provides idea generation, text-based chatting, and image generation capabilities without additional features like saving, sharing, or user accounts.

## App Startup Sequence
The application displays a 0.3-second black screen, followed by a single main startup video that plays in full-screen mode with no borders or letterboxing. Only one video plays during the startup sequence - the latest uploaded video. The video must play entirely from start to finish with no truncation or early termination. The video plays silently without any audio playback.

**Critical Playback Requirements:**
- Only one video plays during startup - no duplicate or secondary video playback
- The video must play completely from beginning to end without any premature ending
- The application must wait for the video's natural end event before transitioning to homepage
- No early transitions, skips, or premature endings are allowed
- The video plays silently with no audio output
- No lag, glitches, or playback artifacts during video display
- Robust playback handling across all browsers to ensure smooth performance
- The video must play completely from beginning to end throughout its entire duration
- Eliminate any duplicate video triggers or secondary playback instances

**Fixed Transition Requirements:**
- After the video completes at its natural end, the application must automatically transition to the main homepage without delays or getting stuck
- Use proper event listeners (e.g., onended handler) to detect video completion and trigger the transition
- Ensure smooth, immediate transition to the homepage once the video finishes
- No manual intervention or additional clicks required after video completion

## Core Features

### Landing Page
- Clean, minimalist design with modern UI
- Prominent text banner at the top displaying: **"This website was created by Bhairav Mani.R / Yeshwanth.B"** with a glowing/neon text effect
- Dark background with colorful gradient orbs and lighting effects matching the provided design style
- Clear navigation to the Jogo AI functionality
- New character image (`sukuna-character-transparent.png`) positioned at the bottom-right corner of the homepage with transparent background
- Character displays with appropriate scaling to match previous character's size and aspect ratio
- Gently pulsing arrow above the character labeled "click me"
- When users click the character, display dialog: "Ryomen Sukuna says 'This website is created by Bhairav Mani.R gambare gambare'"

### Jogo AI Assistant
The application provides multiple AI-powered features through Jogo:

#### Idea Generation
- Category-Based Browsing: Predefined categories (Projects, Creativity, Greetings, Web Creation)
- Users select a category to receive relevant idea suggestions from Jogo
- Each category generates multiple AI-powered ideas specific to that domain
- Free-Text Search: Search bar where users can enter any prompt or topic
- Jogo processes the input and returns filtered, relevant idea suggestions
- Results are tailored to the user's specific query

#### Text-Based Chat Interface
- ChatGPT-like conversational interface with Jogo
- Users can engage in natural language conversations
- Jogo provides helpful responses and assistance beyond just idea generation

#### Image Generation
- Users can type prompts to generate images through Jogo
- Optional image generation feature integrated with the chat interface
- Generated images are displayed within the conversation

### User Interface
- Simple, modern design focused on AI interaction
- Dark theme with vibrant gradient background featuring colorful orbs
- Responsive layout for desktop and mobile devices
- Intuitive navigation between idea generation, chat, and image generation features
- Clean presentation of generated content in the appropriate display components
- Toast messages for user feedback (success or error states) instead of failure text
- Glowing text effects for the creator attribution banner
- Interactive character element with click functionality and consistent visual theme

## Backend Requirements
The backend must store and provide:
- Category definitions and associated prompts
- Fully functional AI integration for idea generation that successfully communicates with OpenAI API and returns valid responses
- Working `generateIdea` API endpoint for free-text search queries that consistently returns successful idea suggestions without failures
- Working `getCategoryIdea` API endpoint for category-based queries that reliably returns proper idea responses
- Functional chat API endpoints for text-based conversations with Jogo that successfully process requests and return meaningful responses
- Working image generation API endpoints for processing user prompts and returning generated images
- Robust error handling and retry logic to prevent "failed to generate ideas" errors
- Reliable request processing for all AI features that consistently returns successful responses to the frontend
- Proper OpenAI API integration with valid authentication and request formatting

## Technical Notes
- All content and interactions are in English
- No user authentication or data persistence required
- Focus on fast, responsive AI interactions with reliable backend connectivity
- AI responses should be concise and actionable
- Frontend must dynamically display generated content and provide user feedback through toast notifications
- The AI assistant is consistently referred to as "Jogo" throughout the application
- Maintain existing site layout, background wallpaper, and visual components
- Ensure all AI generation features work reliably without showing failure messages
- The startup video must play completely without any truncation or premature ending with robust cross-browser compatibility and plays silently without audio
- Ensure only one video plays during startup sequence with no duplicate playback instances
- Fix the startup sequence transition to automatically show the homepage after video completion using proper event listeners
